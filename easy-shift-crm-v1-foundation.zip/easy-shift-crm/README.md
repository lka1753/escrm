# Easy Shift Lead CRM

V1 foundation for the Easy Shift multi-company lead distribution CRM.

## Current build
- Responsive admin UI scaffold
- Dashboard KPIs
- Partner performance view
- Lead list/search
- Lead status/source UI
- Supabase/PostgreSQL schema for companies, profiles, leads, assignments, status history, calls, activity logs and conversions

## Next implementation stages
1. Supabase auth + complete RLS policies
2. CRUD for leads/partners/users
3. Telegram bot
4. WordPress lead webhook
5. Superfone webhook adapter
6. Google Ads conversion queue
7. Meta CAPI
8. Reporting/export
9. Stape/sGTM integration

## Run
npm install
npm run dev
